#!/bin/bash
# Script by Sean Shuping
# This script unpacks the precomipled zabbix agents for Solaris 11 x86
#
BUILDDIR=$(pwd)
echo $(date) > $BUILDDIR/install.log
echo '### untar zabbix agent bundle ###' >> $BUILDDIR/install.log

tar -xvf zabbix_agents_2.4.1.solaris11.amd64.tar.gz | cat >> $BUILDDIR/install.log

echo '###' >> $BUILDDIR/install.log
echo '### copying contents to destination directories ###' >> $BUILDDIR/install.log

mkdir -p /usr/local
cp -r $BUILDDIR/bin /usr/local | cat >> $BUILDDIR/install.log
cp -r $BUILDDIR/sbin /usr/local | cat >> $BUILDDIR/install.log
mkdir -p /usr/local/etc
cp -r $BUILDDIR/conf/* /usr/local/etc  | cat >> $BUILDDIR/install.log
echo '### directory listing for /var/local ###' >> $BUILDDIR/install.log
ls -l /usr/local | cat >> $BUILDDIR/install.log

echo '### create zabbix user and group ###' >> $BUILDDIR/install.log
groupadd -g 999 zabbix
useradd -u 999 -g zabbix zabbix

echo '### create zabbix.xml file to deliver to SMF ###' >> $BUILDDIR/install.log

svcbundle -o $BUILDDIR/zabbix.xml -s service-name=application/zabbix-agent -s model=daemon -s start-method="/usr/local/sbin/zabbix_agentd"
echo ' zabbix xml created copying to destination' 
echo ' ### copy zabbix.xml into /lib/svc/manifest/site for SMF to recognize zabbix_agentd as SMF service ### ' >> $BUILDDIR/install.log
cp $BUILDDIR/zabbix.xml /lib/svc/manifest/site
echo ' ### xml copied ### ' >> $BUILDDIR/install.log
echo ' ### restarting manifest-import service ### ' >> $BUILDDIR/install.log
svcadm restart svc:/system/manifest-import:default 
sleep 5
echo ' ### disabling zabbix-agent service until configuration file is updated ### ' >> $BUILDDIR/install.log
svcadm disable svc:/application/zabbix-agent:default
svcs -a | grep zabbix | cat >> $BUILDDIR/install.log
echo ' ### end of install, please update /usr/local/etc/zabbix_agentd.conf ### '
echo ' Please update the zabbix server address in /usr/local/etc/zabbix_agentd.conf to reflect that of you zabbix server'
echo " Once complete please run 'svcadm enable svc:/application/zabbix-agent:default' to enable zabbix agent daemon "

